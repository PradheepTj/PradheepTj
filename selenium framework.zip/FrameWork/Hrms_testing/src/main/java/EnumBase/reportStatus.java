package EnumBase;

public enum reportStatus {
	
	 PASS,FAIL,INFO,WARNING

}

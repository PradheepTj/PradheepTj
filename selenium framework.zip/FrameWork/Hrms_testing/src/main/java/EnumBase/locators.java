package EnumBase;

public enum locators {
	
	 id, name, xpath, link, className, css,PartialLinktext

}

package EnumBase;

public enum browser {
	
	
	  CHROME,FIREFOX,EDGE

}

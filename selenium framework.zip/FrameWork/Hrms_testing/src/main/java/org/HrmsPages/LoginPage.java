package org.HrmsPages;

import org.SeleniumBase.Seleniumbase;

import EnumBase.locators;



public class LoginPage extends Seleniumbase {
	
	
	//Action
	/**
	 * @author 
	 * @return 
	 * @Note Ui Validation On the login Page( Heading,Username Lable,password Lable,btn Lable,)
	 * Check the Lable Using IsDisplayed function
	 */
	
	
	public boolean HeadingNameLable () {
		
	
		return element(locators.xpath, "//h4[text()='Sign in']").isDisplayed();
		
	}
	
	public boolean enterUsernameLable () {
		
		return element(locators.xpath, "/html/body/div/div/div/form/div[1]/div[1]/label").isDisplayed();
		
	}
	
	public boolean enterPasswordLable () {
		
		return element(locators.xpath, "//label[text()='Password']").isDisplayed();
		
	}

	
	
	
	public boolean ClickBtnLable () {
		
	return	 element(locators.xpath, "//button[contains(@class,'btn btn-primary')]").isDisplayed();
		
	}
	
	/**
	 * 
	 * @param username password Click sign in btn  navigate to next  window pages
	 * @return
	 */
	
	
	//locators
	public LoginPage EnterUsername(String username) {
		
		element(locators.xpath, "(//input[@class='form-control'])[1]").sendKeys(username);
		return this;
		
		
	}
	public LoginPage EnterPassword(String password) {
		
		element(locators.xpath, "(//input[@class='form-control'])[2]").sendKeys(password);
		return this;
		
		
		
	}
	
	/**
	 * @Notes Navigate to Create Account Page
	 * @return
	 */ 
	
	public DashBoardPage ClickLoginBtn() {
		
		element(locators.xpath, "//button[contains(@class,'btn btn-primary')]").click();
		
		return new DashBoardPage();
		
	}
	
	/**
	 * @Notes Navigate to Create Account Page
	 * @return
	 */
	
	public createAcoountPage CreateAccount() {
		
		element(locators.xpath, "//div[@class='col-md-4 col-md-offset-4']//a[1]").click();
		
		return new createAcoountPage();
		
	}
	
	
	
	
	public void LoginPageNavigate(String username,String password) {
		
		EnterUsername(username);
		EnterPassword(password);
		ClickLoginBtn();
		
	}
	
}

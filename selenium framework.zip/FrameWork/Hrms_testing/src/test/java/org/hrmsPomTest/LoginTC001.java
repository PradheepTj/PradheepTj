package org.hrmsPomTest;

import java.io.IOException;
import org.HrmsPages.LoginPage;
import org.SeleniumBase.Seleniumbase;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import EnumBase.locators;


public class LoginTC001 extends Seleniumbase {

	@BeforeMethod
	void launchBrowserGeturl() {

		setUp("http://localhost/hrms/"); 

	}


	@AfterMethod
	void tearDown() {

		quit();
	}

	@Test(priority=0)
	void GetUrl() {

		String url = driver.getCurrentUrl();
		stepReport("info", "Actual Url :"+url);
		stepReport("info", "Expected Url :"+"http://localhost/hrms/");
		stepReport("info", "verify the actual and expected Url");

		String ActualUrl = driver.getCurrentUrl();
		String ExpectedUrl = "http://localhost/hrms/";
		Assert.assertEquals(ExpectedUrl, ActualUrl);	
	}


	@Test(priority=1)
	void HrmsLoginGetTitle() throws IOException{

		String title = driver.getTitle();
		stepReport("info", "Actual title :"+title);
		stepReport("info", "Expected title :"+"sign in");
		stepReport("info", "verify the actual and expected titile");

		String ActualTitle = driver.getTitle();
		String ExpectedTitle = "Sign in";
		Assert.assertEquals(ExpectedTitle, ActualTitle);	
	}


	@Test(priority=2)
	void HeadingNameLableName (){

		LoginPage Lp =new LoginPage();
		Boolean headingName =	Lp.HeadingNameLable();

		Assert.assertTrue(headingName);
		stepReport("info","isDisplayed heading Name : "+headingName);

		String text = element(locators.xpath, "//h4[text()='Sign in']").getText();
		stepReport("info", "-------Actual Text------- :"+text);
		stepReport("info", "-------Expected Text----- :"+"Sign in");
		stepReport("info","---verify the actual and expected text---");

		String Actualtext = element(locators.xpath, "//h4[text()='Sign in']").getText();
		String ExpectedText="ign in";

		Assert.assertEquals(Actualtext, ExpectedText);

		System.out.println("------- text Verify -----");

	}

	@Test(priority=3)
	void UserNameLableName()  {

		// Validation on the Username Fields 
		LoginPage Lp =new LoginPage();
		Boolean email =	Lp.enterUsernameLable();

		Assert.assertTrue(email);
		stepReport("info","-@-$-#- Heading Name -$-#-@- : "+email);

		//
		String text = element(locators.xpath, "//label[text()='Email']").getText();
		stepReport("info", "******Actual Text***** :"+text);
		stepReport("info", "######Expected Text##### :"+"Email");
		stepReport("info","verify the actual and expected text:---++++");

		String Actualtext = element(locators.xpath, "//label[text()='Email']").getText();
		String ExpectedText="Email";

		Assert.assertEquals(Actualtext, ExpectedText);

		System.out.println(" Pass lable text Verify ");

	}
	@Test(priority=4)
	void PasswordLableName()  {

		LoginPage Lp =new LoginPage();
		Boolean Password =	Lp.enterUsernameLable();

		SoftAssert softAsrt= new SoftAssert();

		softAsrt.assertTrue(Password);
		stepReport("info","-@-$-#- Heading Name -$-#-@- : "+Password);

		//
		String text = element(locators.xpath, " //label[text()='Password'] ").getText();
		stepReport("info", "******Actual Text***** :"+text);
		stepReport("info", "######Expected Text##### :"+"Password");
		stepReport("info","verify the actual and expected text:---++++");

		String Actualtext = element(locators.xpath, "//label[text()='Password'] ").getText();
		String ExpectedText="Password";

		//Assert.assertEquals(Actualtext, ExpectedText);
		softAsrt.assertEquals(Actualtext, ExpectedText);
		System.out.println(" Pass lable text Verify ");

	}
	
	
	@Test(priority=5)
	void LoginBtnlableName() {

		LoginPage Lp =new LoginPage();
		Boolean Click =	Lp.enterUsernameLable();

		Assert.assertTrue(Click);
		stepReport("info","-@-$-#- Heading Name -$-#-@- : "+Click);
		//
		String text = element(locators.xpath, " //button[contains(@class,'btn btn-primary')] ").getText();
		stepReport("info", "******Actual Text***** :"+text);
		stepReport("info", "######Expected Text##### :"+"Sign in");
		stepReport("info","verify the actual and expected text:---++++");

		String Actualtext = element(locators.xpath, "//button[contains(@class,'btn btn-primary')] ").getText();
		String ExpectedText="Sign in";
		Assert.assertEquals(Actualtext, ExpectedText);


	}

//	@Test(priority=7)
//	void DashboardPage() {
//		LoginPage Lp =new LoginPage();
//
//	
//
//	}

	@Test(priority=6)
	void logIn_Into_Navigate_to_Dashboard__() throws InterruptedException {
		LoginPage Lp =new LoginPage();
		
		Lp.EnterUsername("Prad@gmail.com");
		Lp.EnterPassword("Pradeep");
//		String WindowHandle =driver.getWindowHandle();
//		stepReport("info", "Login Window: " +WindowHandle);
//		System.out.println("login Window : " +WindowHandle);
//		
	    Lp.ClickLoginBtn();
	    
	    Thread.sleep(5000);
	    
	    stepReport("Info", "Dashboard Url :"+ getURL());
	   
	    switchToWindow(0);

//		Set<String> windowhandles=    driver.getWindowHandles();
//		System.out.println(windowhandles);
//		List<String> list = new ArrayList<String>(windowhandles);
//		driver.switchTo().window(list.get(1));
//		System.out.println(driver.getCurrentUrl());
//		driver.switchTo().window(list.get(0));
//		
//		Set<String> windowhandles2=	driver.getWindowHandles();
//		list.clear();
//		list.addAll(windowhandles2);
//		driver.switchTo().window(list.get(0));
//		String str=driver.getCurrentUrl();
//		System.out.println(str);
		

	}




}

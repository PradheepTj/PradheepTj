package org.Listener;



import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import java.nio.file.Paths;

import javax.imageio.ImageIO;

import org.SeleniumBase.Seleniumbase;
import org.Utils.ExtentManager;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;

public class listenerImp extends Seleniumbase   implements ITestListener{


	public void onTestStart(ITestResult result) {

		//before each test case
		test=extent.createTest( result.getMethod().getMethodName());
		createTest( "Pradheep", "Sanity");
		

	}

	public void onTestSuccess(ITestResult result) {
		stepReport("Pass", "Test Case :  "+result.getMethod().getMethodName()+"   _Is Passed");
		
		
//		File screen = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//	  	BufferedImage img = null;
//		try {
//			img = ImageIO.read(screen);
//		} catch (IOException e1) {
//			// TODO Auto-generated catch block
//			e1.printStackTrace();
//		}
//	  	File filetest = Paths.get(".").toAbsolutePath().normalize().toFile();
//	  	try {
//			ImageIO.write(img, "png", new File(filetest + "\\Screenshots\\" +result.getName()+ ".png"));
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//	  	//Log Screenshot in Report
//	  	test.pass("Details of " + "Test screenshot", MediaEntityBuilder
//	  	                .createScreenCaptureFromPath(System.getProperty("user.dir") + "./Screenshots/" +result.getName()+ ".png").build());

	}


	public void onTestFailure(ITestResult result)  {
	stepReport("Fail", "TestCase : "+result.getMethod().getMethodName()+" is Failed");
  	test.log(Status.FAIL,result.getThrowable() );
  	
  	File screen = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
  	BufferedImage img = null;
	try {
		img = ImageIO.read(screen);
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
  	File filetest = Paths.get(".").toAbsolutePath().normalize().toFile();
  	try {
		ImageIO.write(img, "png", new File(filetest + "\\Screenshots\\" +result.getName()+ ".png"));
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

  	//Log Screenshot in Report
  	test.fail("Details of " + "Test screenshot", MediaEntityBuilder
  	                .createScreenCaptureFromPath(System.getProperty("user.dir") + "./Screenshots/" +result.getName()+ ".png").build());
  
	}
	


	public void onTestSkipped(ITestResult result) {

		stepReport("Skip", "Test Case : "+result.getMethod().getMethodName()+"isSkiped");

	}


	
	
	public void onStart(ITestContext context) {
		//setup method call

		extent = ExtentManager.startReport();
		
	}


	
	
	
	public void onFinish(ITestContext context) {
		// close extent
		extent.flush();

	}
	
	


}
